class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else ("EOF", "")

    def advance(self):
        tok = self.peek()
        self.pos += 1
        return tok

    def match(self, expected_type):
        if self.peek()[0] == expected_type:
            return self.advance()
        else:
            raise SyntaxError(f"Beklenen {expected_type}, bulundu: {self.peek()}")

    def parse(self):
        program = []
        while self.peek()[0] != "EOF":
            stmt = self.statement()
            if stmt:
                program.append(stmt)
        return program

    def statement(self):
        tok_type, tok_val = self.peek()

        if tok_val == "print":
            return self.parse_print()
        elif tok_val == "var":
            return self.parse_var()
        elif tok_val == "opr":
            return self.parse_opr()
        elif tok_val == "func":
            return self.parse_func()
        elif tok_val == "trigger":
            return self.parse_trigger()
        elif tok_val == "if":
            return self.parse_if()
        elif tok_val == "input":
            return self.parse_input()
        else:
            self.advance()
            return None  # veya hata ver

    def parse_print(self):
        self.match("IDENT")  # print
        self.match("LPAREN")
        args = self.parse_arguments()
        self.match("RPAREN")
        return ("print", args)

    def parse_arguments(self):
        args = []
        while True:
            tok_type, tok_val = self.peek()
            if tok_type in ("STRING", "IDENT", "NUMBER"):
                args.append(self.advance())
            if self.peek()[0] == "COMMA":
                self.advance()
                continue
            else:
                break
        return args

    def parse_var(self):
        self.match("IDENT")  # var
        name = self.match("IDENT")[1]
        self.match("OP")     # =
        value = self.advance()
        return ("var_assign", name, value)

    def parse_opr(self):
        self.match("IDENT")  # opr
        self.match("LPAREN")
        left = self.match("IDENT")[1]
        op = self.match("OP")[1]
        right = self.match("IDENT")[1]
        self.match("RPAREN")
        return ("operation", left, op, right)

    def parse_func(self):
        self.match("IDENT")  # func
        name = self.match("IDENT")[1]
        self.match("LPAREN")
        body = []
        while self.peek()[1] != "end":
            stmt = self.statement()
            if stmt:
                body.append(stmt)
        self.match("IDENT")  # end
        self.match("RPAREN")
        return ("function_def", name, body)

    def parse_trigger(self):
        self.match("IDENT")  # trigger
        func_name = self.match("IDENT")[1]
        self.match("LPAREN")
        self.match("RPAREN")
        return ("trigger", func_name)

    def parse_if(self):
        self.match("IDENT")  # if
        cond_left = self.match("IDENT")[1]
        self.match("OP")     # =
        cond_right = self.advance()[1]
        conditions = [(cond_left, "=", cond_right)]

        if self.peek()[1] == "and":
            self.advance()  # and
            cond_left2 = self.match("IDENT")[1]
            self.match("OP")
            cond_right2 = self.advance()[1]
            conditions.append((cond_left2, "=", cond_right2))

        self.match("LBRACE")
        true_body = []
        while self.peek()[0] != "RBRACE":
            stmt = self.statement()
            if stmt:
                true_body.append(stmt)
        self.match("RBRACE")

        false_body = []
        if self.peek()[1] == "else":
            self.match("IDENT")
            self.match("LBRACE")
            while self.peek()[0] != "RBRACE":
                stmt = self.statement()
                if stmt:
                    false_body.append(stmt)
            self.match("RBRACE")

        return ("if", conditions, true_body, false_body)

    def parse_input(self):
        self.match("IDENT")  # input
        self.match("LPAREN")
        args = self.parse_arguments()
        self.match("RPAREN")
        return ("input", args)class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else ("EOF", "")

    def advance(self):
        tok = self.peek()
        self.pos += 1
        return tok

    def match(self, expected_type):
        if self.peek()[0] == expected_type:
            return self.advance()
        else:
            raise SyntaxError(f"Beklenen {expected_type}, bulundu: {self.peek()}")

    def parse(self):
        program = []
        while self.peek()[0] != "EOF":
            stmt = self.statement()
            if stmt:
                program.append(stmt)
        return program

    def statement(self):
        tok_type, tok_val = self.peek()

        if tok_val == "print":
            return self.parse_print()
        elif tok_val == "var":
            return self.parse_var()
        elif tok_val == "opr":
            return self.parse_opr()
        elif tok_val == "func":
            return self.parse_func()
        elif tok_val == "trigger":
            return self.parse_trigger()
        elif tok_val == "if":
            return self.parse_if()
        elif tok_val == "input":
            return self.parse_input()
        else:
            self.advance()
            return None  # veya hata ver

    def parse_print(self):
        self.match("IDENT")  # print
        self.match("LPAREN")
        args = self.parse_arguments()
        self.match("RPAREN")
        return ("print", args)

    def parse_arguments(self):
        args = []
        while True:
            tok_type, tok_val = self.peek()
            if tok_type in ("STRING", "IDENT", "NUMBER"):
                args.append(self.advance())
            if self.peek()[0] == "COMMA":
                self.advance()
                continue
            else:
                break
        return args

    def parse_var(self):
        self.match("IDENT")  # var
        name = self.match("IDENT")[1]
        self.match("OP")     # =
        value = self.advance()
        return ("var_assign", name, value)

    def parse_opr(self):
        self.match("IDENT")  # opr
        self.match("LPAREN")
        left = self.match("IDENT")[1]
        op = self.match("OP")[1]
        right = self.match("IDENT")[1]
        self.match("RPAREN")
        return ("operation", left, op, right)

    def parse_func(self):
        self.match("IDENT")  # func
        name = self.match("IDENT")[1]
        self.match("LPAREN")
        body = []
        while self.peek()[1] != "end":
            stmt = self.statement()
            if stmt:
                body.append(stmt)
        self.match("IDENT")  # end
        self.match("RPAREN")
        return ("function_def", name, body)

    def parse_trigger(self):
        self.match("IDENT")  # trigger
        func_name = self.match("IDENT")[1]
        self.match("LPAREN")
        self.match("RPAREN")
        return ("trigger", func_name)

    def parse_if(self):
        self.match("IDENT")  # if
        cond_left = self.match("IDENT")[1]
        self.match("OP")     # =
        cond_right = self.advance()[1]
        conditions = [(cond_left, "=", cond_right)]

        if self.peek()[1] == "and":
            self.advance()  # and
            cond_left2 = self.match("IDENT")[1]
            self.match("OP")
            cond_right2 = self.advance()[1]
            conditions.append((cond_left2, "=", cond_right2))

        self.match("LBRACE")
        true_body = []
        while self.peek()[0] != "RBRACE":
            stmt = self.statement()
            if stmt:
                true_body.append(stmt)
        self.match("RBRACE")

        false_body = []
        if self.peek()[1] == "else":
            self.match("IDENT")
            self.match("LBRACE")
            while self.peek()[0] != "RBRACE":
                stmt = self.statement()
                if stmt:
                    false_body.append(stmt)
            self.match("RBRACE")

        return ("if", conditions, true_body, false_body)

    def parse_input(self):
        self.match("IDENT")  # input
        self.match("LPAREN")
        args = self.parse_arguments()
        self.match("RPAREN")
        return ("input", args)
        #written byu seaofc0de
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.9.1/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup
} from "https://www.gstatic.com/firebasejs/11.9.1/firebase-auth.js";
import {
  getFirestore,
  doc,
  getDoc,
  setDoc
} from "https://www.gstatic.com/firebasejs/11.9.1/firebase-firestore.js";

// Firebase yapılandırman
const firebaseConfig = {
  apiKey: "AIzaSyC5S4Iw8xFcc12DETsLJljnbdSPuqFumU0",
  authDomain: "delyra-app.firebaseapp.com",
  projectId: "delyra-app",
  storageBucket: "delyra-app.firebasestorage.app",
  messagingSenderId: "183431812768",
  appId: "1:183431812768:web:d387368f02aa00f41fdbc5"
};

// Başlat
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const provider = new GoogleAuthProvider();

document.getElementById("authForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const confirm = document.getElementById("passwordConfirm").value;

  if (password !== confirm) {
    alert("Şifreler eşleşmiyor");
    return;
  }

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    console.log("Giriş başarılı", userCredential);
    window.location.href = "chatlist.html";
  } catch (error) {
    console.warn("Giriş başarısız:", error.code, error.message);

    if (error.code === "auth/user-not-found") {
      try {
        const newUser = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, "users", newUser.user.uid), { email });
        window.location.href = "username.html";
      } catch (createError) {
        alert("Kayıt başarısız: " + createError.message);
      }
    } else {
      alert("Giriş başarısız: " + error.message);
    }
  }
});

document.getElementById("googleSignInBtn").addEventListener("click", async () => {
  try {
    const result = await signInWithPopup(auth, provider);
    const user = result.user;

    const userRef = doc(db, "users", user.uid);
    const snap = await getDoc(userRef);

    if (!snap.exists()) {
      await setDoc(userRef, { email: user.email });
      window.location.href = "username.html";
    } else {
      window.location.href = "chatlist.html";
    }
  } catch (err) {
    alert("Google hatası: " + err.message);
  }
});s
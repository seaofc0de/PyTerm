import os
from datetime import datetime
import sys

variables = {}
functions = {}

help_docs = {
    "print":    'print("metin", değişken)   → Ekrana çıktı verir.',
    "var":      'var x = 5                  → Değişken tanımlar.',
    "opr":      'opr(x + y)                 → Sayı/string işlemleri yapar.',
    "function": 'function myFunc() ... end()→ Fonksiyon tanımlar.',
    "trigger":  'trigger myFunc()           → Fonksiyon çalıştırır.',
    "input":    'input("Soru", x)           → Girdi alır, x değişkenine atar.',
    "if":       'if x = y {...} else {...}  → Koşullu yapı.',
    "exit":     'trigger exitSOC()          → SOC terminalinden çıkar.',
    "clear":    'trigger clearScreen()      → Ekranı temizler.',
    "help":     'help() veya help("komut")  → Yardım mesajı gösterir.'
}

def soc_help(command=None):
    if command is None or command.strip() == "":
        print("=== SOC LANGUAGE HELP ===")
        for name, desc in help_docs.items():
            print(f"{desc}")
        print("=========================")
    else:
        found = help_docs.get(command)
        if found:
            print(f"{found}")
        else:
            print(f"[SOC HELP] No syntax info found for '{command}'")

def soc_print(args):
    output = []
    for arg in args:
        if arg in variables:
            output.append(str(variables[arg]))
        elif arg.startswith('"') and arg.endswith('"'):
            output.append(arg[1:-1])
        else:
            output.append(arg)
    
    final_output = " ".join(output)

    # Sistem özel komutları kontrol
    if final_output == "::exit_program":
        print("[EXIT] Goodbye.")
        sys.exit(0)
    elif final_output == "::clear_terminal":
        os.system("cls" if os.name == "nt" else "clear")
    elif final_output == "::show_clock":
        print("[TIME]", datetime.now().strftime("%H:%M:%S"))
    else:
        print(final_output)

def soc_var(name, value):
    if value.startswith('"') and value.endswith('"'):
        variables[name] = value[1:-1]
    elif value.isdigit():
        variables[name] = int(value)
    else:
        if value in variables:
            variables[name] = variables[value]
        else:
            variables[name] = value

def soc_opr(operation, left, right):
    x = variables.get(left, left)
    y = variables.get(right, right)

    # String mi, int mi kontrol
    if isinstance(x, str) and isinstance(y, str):
        if operation == "+":
            print(x + y)
        elif operation == "-":
            result = ''.join([c for c in x if c not in y])
            print(result)
        else:
            print("[ERROR] Invalid string operation:", operation)
    else:
        try:
            x = int(x)
            y = int(y)
            if operation == "+":
                print(x + y)
            elif operation == "-":
                print(x - y)
            elif operation == "*":
                print(x * y)
            elif operation == "/":
                print(x / y if y != 0 else "[ERROR] Division by zero")
        except:
            print("[ERROR] Invalid operands")

def soc_func(name, body):
    functions[name] = body

def soc_trigger(name):
    if name in functions:
        for line in functions[name]:
            interpret(line)
    else:
        print(f"[ERROR] Function '{name}' not found")

def soc_input(prompt, varname):
    answer = input(prompt + " ")
    variables[varname] = answer

def soc_if(x, y, true_body, false_body=None):
    x_val = variables.get(x, x)
    y_val = variables.get(y, y)
    if str(x_val) == str(y_val):
        for line in true_body:
            interpret(line)
    else:
        if false_body:
            for line in false_body:
                interpret(line)

def interpret(command):
    if isinstance(command, dict):
        cmd = command.get("type")

        if cmd == "print":
            soc_print(command.get("args", []))
        elif cmd == "var":
            soc_var(command["name"], command["value"])
        elif cmd == "opr":
            soc_opr(command["op"], command["left"], command["right"])
        elif cmd == "function":
            soc_func(command["name"], command["body"])
        elif cmd == "trigger":
            soc_trigger(command["name"])
        elif cmd == "input":
            soc_input(command["prompt"], command["varname"])
        elif cmd == "if":
            soc_if(
                command["x"],
                command["y"],
                command.get("true_body", []),
                command.get("false_body", [])
            )
        elif cmd == "help":
            arg = command.get("arg")
            soc_help(arg)
        else:
            print("[ERROR] Unknown command:", cmd)
    else:
        print("[ERROR] Invalid command structure")
import re

# Token types
TOKEN_TYPES = [
    ("NUMBER",     r"\d+"),
    ("STRING",     r"\".*?\""),
    ("IDENT",      r"[a-zA-Z_][a-zA-Z0-9_]*"),
    ("OP",         r"[+\-*/=]"),
    ("COMMA",      r","),
    ("LPAREN",     r""),
    ("RPAREN",     r""),
    ("LBRACE",     r"\{"),
    ("RBRACE",     r"\}"),
    ("NEWLINE",    r"\n"),
    ("SKIP",       r"[ \t]+"),
    ("COMMENT",    r"#.*"),
]

token_regex = "|".join(f"(?P<{name}>{regex})" for name, regex in TOKEN_TYPES)
token_pattern = re.compile(token_regex)

def tokenize(code):
    tokens = []
    for match in token_pattern.finditer(code):
        kind = match.lastgroup
        value = match.group()
        if kind == "SKIP" or kind == "COMMENT":
            continue
        tokens.append((kind, value))
    return tokens
    #Written by seaofc0de
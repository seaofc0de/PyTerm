import time
import sys

variables = {}
functions = {}

def splash():
    splash_text = r"""
   _____   ____   ____  
  / ____| / __ \ / __ \ 
 | (___  | |  | | |  | |
  \___ \ | |  | | |  | |
  ____) || |__| | |__| |
 |_____/  \____/ \____/ 

SOC - Scripted Operating Console
Version 1.0.0
(c) 2025 seaofc0de

Type 'help' for commands.
"""
    print(splash_text)
    time.sleep(1)  # 1 saniye bekle

def handle_var(cmd):
    try:
        _, rest = cmd.split("var", 1)
        name, value = rest.split("=", 1)
        variables[name.strip()] = value.strip()
        print(f"[VAR] {name.strip()} = {value.strip()}")
    except:
        print("Invalid syntax. Use: var name = value")

def handle_print(cmd):
    _, rest = cmd.split("print", 1)
    rest = rest.strip()
    if rest.startswith('"') and rest.endswith('"'):
        print(rest[1:-1])
    elif rest in variables:
        print(variables[rest])
    else:
        print(f"[SOC] {rest}")

def handle_function(cmd_lines, func_name):
    functions[func_name] = cmd_lines
    print(f"[FUNC] Defined function: {func_name}")

def handle_trigger(func_name):
    if func_name in functions:
        for line in functions[func_name]:
            execute(line)
    else:
        print(f"[ERROR] Function '{func_name}' not found.")

def handle_opr(block):
    print("[OPR] Operation block executing:")
    lines = block.strip().split(";")
    for line in lines:
        execute(line.strip())

def execute(cmd):
    if cmd.startswith("var "):
        handle_var(cmd)
    elif cmd.startswith("print "):
        handle_print(cmd)
    elif cmd.startswith("trigger(") and cmd.endswith(")"):
        func_name = cmd[8:-1].strip()
        handle_trigger(func_name)
    elif cmd.startswith("opr{") and cmd.endswith("}"):
        block = cmd[4:-1]
        handle_opr(block)
    else:
        print(f"[UNKNOWN] {cmd}")

def main():
    splash()
    multiline_mode = False
    func_buffer = []
    func_name = ""

    while True:
        try:
            cmd = input("soc > ").strip()
            if cmd == "exit":
                print("Exiting SOC...")
                break
            elif cmd == "help":
                print("Commands:")
                print(" - var name = value")
                print(" - print \"text\" or variable name")
                print(" - function(funcName)")
                print("   ...lines...")
                print("   end()")
                print(" - trigger(funcName)")
                print(" - opr{ statement1; statement2 }")
            elif cmd.startswith("function(") and cmd.endswith(")"):
                func_name = cmd[9:-1]
                func_buffer = []
                multiline_mode = True
                print(f"[FUNC] Defining {func_name}...")
            elif cmd == "end()" and multiline_mode:
                handle_function(func_buffer, func_name)
                multiline_mode = False
            elif multiline_mode:
                func_buffer.append(cmd)
            else:
                execute(cmd)
        except KeyboardInterrupt:
            print("\n[INTERRUPTED]")
            break
        except Exception as e:
            print(f"[ERROR] {e}")

if __name__ == "__main__":
    main()